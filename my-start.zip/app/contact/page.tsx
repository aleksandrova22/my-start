export default function Page2() {
    return <h1>Обо мне</h1>
  }