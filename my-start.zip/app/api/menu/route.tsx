import { prisma } from '@/prisma/prisma';

import { NextResponse } from 'next/server';


// общедоступное API
export async function GET() {
 

  return NextResponse.json(
    await prisma.menu.findMany()
  );
}