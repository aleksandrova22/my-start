"use client";

import {FormCalc} from '../components/Elem/FormCalc';

export default function Home() {
  return <>
  <h1>📇 Калькулятор БЖУ</h1>
  <FormCalc />

  </>;
}
