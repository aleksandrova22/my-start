import type { Menu } from '@prisma/client';

export function Dinner({ menulist }: { menulist: Menu[] }) {
    return  <ol>
    {     menulist?.map(menu => <li key = { menu.id } >
            { menu.name }  {menu.energy} {menu.ingredients}
            </li>)
    }
    </ol>; 
    
    
   
}