'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ReactNode } from 'react';

const
  pages = [
    { href: '/', title: 'Home' },
    { href: '/product', title: 'Product' },
    { href: '/contact', title: 'Contact' },
    { href: '/account', title: 'My account' },
  ];

export default function Header({ children = null }: { children: ReactNode}) {
  const pathname = usePathname();
  console.log(pathname)
  return <header>
    {children}
    <nav>
   
      <ul>
        {pages.map(({ href, title }) =>
          <li key={href} className={pathname === href ? 'active' : ''}>
            <Link href={href}>{title} </Link>
          </li>)}
      </ul>
    </nav>
  </header>
}